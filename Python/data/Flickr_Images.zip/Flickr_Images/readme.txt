Takes about an hour or two to download, unzip, and resize all the images.

Make sure you have:
- pip install kaggle
- pip install cv2
- 100gb+ of space available where you are running it

Just run the python script and let me know if any errors show up :)