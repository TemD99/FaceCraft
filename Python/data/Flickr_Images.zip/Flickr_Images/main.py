import subprocess
import os
import cv2

folder_1024 = '1024x1024/images1024x1024/'
folder_512 = '512x512/'
folder_128 = '128x128/'

DOWNLOAD_IMAGES = True
RESIZE_IMAGES = True

def resize(image, size, output):
    resized = cv2.resize(image, size, interpolation=cv2.INTER_AREA)
    cv2.imwrite(output, resized)

def process():
    i = 1
    for filename in os.listdir(folder_1024):
        if filename.lower().endswith('.png'):
            input = os.path.join(folder_1024, filename)
            output_128 = os.path.join(folder_128, filename)
            output_512 = os.path.join(folder_512, filename)

            image = cv2.imread(input)

            resize(image, (128,128), output_128)
            resize(image, (512,512), output_512)

            print("Image",i,"resized.")
            i += 1

if __name__ == '__main__':
    if DOWNLOAD_IMAGES:
        print("Starting Kaggle Download...")
        download_command = "kaggle datasets download -d rahulbhalley/ffhq-1024x1024 --path 1024x1024/ --unzip"
        subprocess.run(download_command, shell=True)
        print("Kaggle Downloaded and Images Unzipped.")
    
    if RESIZE_IMAGES:
        print("Starting to Resize...")
        process()
        print("Resize Finished.")